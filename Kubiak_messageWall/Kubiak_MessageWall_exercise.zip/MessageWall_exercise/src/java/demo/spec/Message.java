package demo.spec;

public interface Message {
    String getContent();
    String getOwner();
}
